import p1_img from "./product_1.png";
import p2_img from "./product_2.png";
import p3_img from "./product_3.png";
import p4_img from "./product_4.png";
import p5_img from "./product_5.png";
import p6_img from "./product_6.png";
import p7_img from "./product_7.png";
import p8_img from "./product_8.png";
import p9_img from "./product_9.png";



let blog_page_data = [
    
    {

    id: 512,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p1_img,

},
{
    id: 513,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p2_img, 
},
{
    id: 514,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p3_img, 
}
,
{
    id: 515,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p4_img, 
}
,
{
    id: 516,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p5_img, 
}

,
{
    id: 517,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p6_img, 
}
,
{
    id: 518,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p6_img, 
}
,
{
    id: 519,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p6_img, 
}
,
{
    id: 520,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p7_img, 
}
,
{
    id: 521,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p8_img, 
}
,
{
    id: 522,
    name: "Virutalizing The Workspace: Building The Virutal Offices Of Tomorrow",
    Paragraph: "The importance of a metaverse workplace resides in their capacity to create a dynamic and adaptable work environment by overcoming physical constraints. They encourage a globalized approach to talent acquisition by enabling companies to draw in top talent from a variety of geographic areas. Accordingly, companies that use virtual offices frequently witness increased worker productivity, reduced expenses, and improved work-life balance.",
    image: p9_img, 
}
]


export default blog_page_data;